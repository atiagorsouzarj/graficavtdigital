# CHANGELOG - Sistema ERP CRM & Precificação Gráfica Rápida

Todas as alterações notáveis deste projeto serão documentadas neste arquivo.

## [v3.0.0] - 2026-05-18 - Busca Automática CRM em Orçamentos e PDV + Live Search Auto-complete de Produtos

### 🚀 Novidades e Melhorias

1. **Auto-Complete da Busca do Cliente CRM no Orçamento Rápido e PDV:**
   - No modal de Novo Orçamento Rápido e no PDV, o campo de cliente conta com busca inteligente no cadastro CRM.
   - Ao selecionar o cliente (ex: *Studio Design Ltda*, *Raphaela Pinheiro*, *Lucas Mendes*), o sistema preenche automaticamente **Nome, WhatsApp, E-mail, Documento (CPF/CNPJ) e CEP/Endereço de Entrega**!
   - As vendas feitas no PDV e Orçamentos ficam vinculadas ao histórico do cliente no CRM.
2. **Endereço com CEP e ViaCEP no Orçamento Rápido:**
   - Adicionados campos de CEP com botão de busca automática via ViaCEP, Endereço, Bairro, Cidade e UF no modal de orçamento para cálculo do frete via **SuperFrete**.
3. **Live Search Auto-Complete de Produtos em Itens do Orçamento:**
   - O campo "Itens do Orçamento" substituiu o antigo `<select>` por um **Auto-complete com busca em tempo real**. À medida que o operador digita, o menu exibe os produtos correspondentes com seus preços e adiciona com 1 clique.
4. **Alinhamento dos Campos de Itens do Orçamento:**
   - Reorganizado o layout da linha de item (Descrição, Qtd, Preço Un R$, Total R$ e Lixeira) em colunas flexíveis de 12 colunas perfeitamente alinhadas.
5. **Esclarecimento do "Item Avulso":**
   - O botão `+ Item Avulso` permite inserir serviços ou taxas adicionais no orçamento (ex: *Ajuste de Arte R$ 20,00*). Ele é salvo na tabela `quote_order_items` associado ao código daquele orçamento/pedido.

---

## [v2.9.0] - 2026-05-18 - Integração do Estoque na Ficha Técnica (BOM) & Categorias do Catálogo

### 🚀 Novidades e Melhorias
- Busca e seleção direta de materiais no estoque para a Ficha Técnica BOM.
