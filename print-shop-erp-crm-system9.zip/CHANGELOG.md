# CHANGELOG - Sistema ERP CRM & Precificação Gráfica Rápida

Todas as alterações notáveis deste projeto serão documentadas neste arquivo.

## [v3.1.0] - 2026-05-18 - Página Pública de Cadastro, Rastreio de Pedidos em Tempo Real e Calculadora de Comunicação Visual (m²)

### 🚀 Novidades e Melhorias

1. **Página de Cadastro Pública / Autoatendimento (`/cadastro-publico`):**
   - Design moderno alinhado à imagem com divisão em 2 colunas:
     - **Coluna da Esquerda:** Cartões de serviços (Gráfica rápida, Papelaria personalizada, Impressão 3D), carrossel de 3 Banners Promocionais rotativos, links de Redes Sociais e telefone.
     - **Coluna da Direita:** Formulário para Pessoa Física e Jurídica com validação de documento, busca ViaCEP e solicitação do produto desejado.
   - **Página de Obrigado (`/cadastro-publico/obrigado`):** Redirecionamento após o cadastro com mensagem de confirmação e botão direto para o WhatsApp da gráfica.
2. **Página Pública e Interna de Rastreio do Pedido (`/rastreio` e `/rastreio/[code]`):**
   - **Linha do Tempo de 7 Etapas do Pedido:** `Cadastro Concluído` ➔ `Orçamento Gerado` ➔ `Arte Aprovada pelo Cliente` ➔ `Pagamento Concluído` ➔ `Em Produção/Impressão` ➔ `Pronto para Entrega` ➔ `Despachado/Concluído`.
   - Exibe código de rastreamento do SuperFrete (SEDEX/PAC), resumo de itens do pedido e status financeiro.
3. **Módulo de Comunicação Visual ($m^2$ — Banners e Adesivos):**
   - **Calculadora de Banner por $m^2$:** Suporte a área física ($\text{Largura} \times \text{Altura}$). Aplica automaticamente a **trava de custo mínimo fixo de R$ 26,00 para peças $< 1,0\text{m}^2$**.
   - **Calculadora de Adesivos por $m^2$:** Rendimento e aproveitamento por $m^2$ (R$ 40,00/$m^2$).
4. **Painel de Controle:**
   - Nova aba `🌐 Área do Cliente & Página Pública` para editar os títulos, os 3 banners rotativos e regras da página pública.
   - Nova aba `📐 Tabela Comunicação Visual (m²)` para editar preços do $m^2$ do fornecedor e trava mínima.
5. **Correção Fina do Cupom Térmico 80mm:**
   - Ajuste de alinhamento em 38-40 colunas monospaçadas sem quebra na borda direita da bobina.

---

## [v3.0.0] - 2026-05-18 - Busca Automática CRM em Orçamentos e PDV
- Auto-complete de cliente CRM no modal de orçamento e no PDV.
